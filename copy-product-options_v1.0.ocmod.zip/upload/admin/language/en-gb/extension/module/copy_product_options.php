<?php
// Heading
$_['heading_title']       = 'Produtos - Copiar opções em lote';
$_['heading_title1']      = 'Copiar opções em lote';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Você copiou as opções com sucesso!';

// Entry
$_['entry_product']       = 'Produtos:<br /><span class="help">(Autocomplete)</span>';
$_['entry_product_from']  = 'Copiar opções paratir de:';
$_['entry_product_to']    = 'Copiar para os produtos:';

// Error 
$_['error_permission']    = 'Warning: You do not have permission to modify Copy Product Options!';
$_['error_image']         = 'Image width &amp; height dimensions required!';
$_['error_product_from']  = 'Nenhum produto de origem foi selecionado!';
$_['error_product_to']    = 'Ops, você precisa selecionar algum produto!';

$_['text_infos']          = 'Informações gerais<ul>
<li><b>Esquerda</b><ol>
	<li>Selecione o produto do qual deseja copiar as opções</li>
	<li>Apos selecionar o produto clique em verificar opções</li>
	<li>Marque a opção a ser copiada.</li>
</ol></li>
<li><b>Direita</b><ol>
	<li>Comece a digitar e selecione todos os itens no qual deseja copiar as opções</li>
	<li>Clique em aplicar para copiar as opções do item do lado esquerdo.</li>
	<li>Espere o processo terminar.</li>
</ol></li>
</ul>';